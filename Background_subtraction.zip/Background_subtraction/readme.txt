Two python scripts are used in our paper.
Test on: Ubuntu 14.04 LTS, 16.04 LTS 
With python 2.7.10, 2.7.11
RPM.py and Background_subtraction.py are modified from deconvoNorm.py(Version:1.0, Marianne S. Felix, marianne.sabourin-felix.1@ulaval.ca)
platform building is a time-consuming process, good luck to you.
========================================== 
1. RPM.py
this method can not reflect the ture biological enrichment information, but can used to compare enrichment changes (for example, WT and KO sample).
##usage: RPM.py -f (--ChIP sample.bam) -c (--chromosome name) -l (--fragment length) -w (--windowsize) -t (--threshold) -o(--output name)
##example: python BS.py  -f ChIP.bam -c BK000964.3 -l 150 -w 25 -t 0 -o ChIP_RPM

2. Background_subtraction.py
the step "Background Subtraction" is added to the base of deconvoNorm.py
****Note. Its not always need to call for background subtraction, most time, we dont care about how much background signal exists. Only when low-enrichment site is need to analysis, we can refer to the normalization factor, to subtract the background.
-n --normalization factor
you'd need compute the normalization factor between ChIP sample and corresponding Input sample first. Then, the script will subtract the appropriate background before deconvolution and normalization. In our study, we use NCIS to compute normalization factor. 
##usage: Background_subtraction.py  -i (--input sample.bam)  -f (--ChIP sample.bam) -c (--chromosome name) -l (--fragment length) -w (--windowsize) -t (--threshold) -n(--the value of normalization factor) -o(--output name)
##example: python Background_subtraction.py  -i input.bam -f ChIP.bam -c BK000964.3 -n 0.343 -l 150 -w 25 -t 10 -o ChIP_BS

===========================================
When you are in trouble, please feel free to contact us(leiys2002@yahoo.com, Lei lei). We'd try our best to give you help.
2018-7-1